class Thread1 extends Thread {

    Thread1() {

           System.out.print("inside constructor\n ");

    }

 

    public void run() {

           System.out.print("inside run(thread1 class)\n ");

    }

 

}

 

public class New {

    public static void main(String[] args) {

           Thread thread1 = new Thread1() {

                  public void run() {

                        System.out.print("inside main\n ");

                  }

           };

           thread1.start();

    }

}