public class Test {

    public static void main(String[] args)

   {

       

       Object obj = new String("ObjectOrientedProgramming");

       Class c = obj.getClass();

       System.out.println(c.getName());

       // calling garbage collector 

       Test anotherobj = new Test();

       anotherobj = null;

       System.gc();


   }

   @Override

   protected void ____(){

   }

}