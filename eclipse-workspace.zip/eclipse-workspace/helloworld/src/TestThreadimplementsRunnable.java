
public class TestThreadimplementsRunnable implements Runnable{
    volatile int balance;

    public TestThreadimplementsRunnable() {
        // TODO Auto-generated constructor stub
        balance=0;
    }
    
    public void run()
    {
        for (int i = 0; i < 200; i++) {
            balance++;
            }
        System.out.println("Balance is "+ balance);
    }
    
    public static void main(String[] args) throws InterruptedException {
    	TestThreadimplementsRunnable t = new TestThreadimplementsRunnable();
        Thread t1 = new Thread(t);t1.start();t1.join();
        Thread t2 = new Thread(t);t2.start();t2.join();
        Thread t3 = new Thread(t);t3.start();t3.join();
    }
}
 