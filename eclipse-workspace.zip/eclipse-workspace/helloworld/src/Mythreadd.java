class Mythreadd extends Thread

{

public static void main(String [] args)

{

	Mythreadd t = new Mythreadd(); /* Line 5 */

t.run(); /* Line 6 */

}

public void run()

{

for(int i=1; i < 3; ++i)

{

System.out.print(i + "..");

}

}

}