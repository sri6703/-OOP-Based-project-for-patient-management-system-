class Student{ 

    void run(){System.out.println("Student is Called");} 

  } 

 

  class TeachingAssistant extends Student{  

    void run(){System.out.println("TA is called");} 

   

    public static void main(String args[]){ 

Student obj = new TeachingAssistant();

    obj.run();

    } 

  } 