class HelloClass{

HelloClass()

{

System.out.print("Hello3 ");

}

public void hello()

{ System.out.print("Hello1 ");

}

}

class ExtendedHello extends HelloClass

{

ExtendedHello(){

System.out.print("Hello0 ");

}

public void hello(){ System.out.print("Hello2 ");

}

}

public class Driver1 {

public static void main(String[] args)

{

HelloClass a = new ExtendedHello();

HelloClass b = new HelloClass();

b.hello();

a.hello();

}

}