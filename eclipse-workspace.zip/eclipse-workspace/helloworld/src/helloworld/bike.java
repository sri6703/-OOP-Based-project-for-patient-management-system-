package helloworld;
 class Pill

{

 void method2()

{

	System.out.println("Pill 2");

}

}

 class Box extends Pill

{

 void method2()

{

	System.out.println("Box 2");

}

 void method3()

{

method2();

System.out.println("Box 3");

}

}

 class Cup extends Box

{

public void method1()

{

	System.out.println("Cup 1");

}

public void method2()

{

	System.out.println("Cup 2");

super.method2();

}

}

 class Jar extends Box

{

public void method1()

{

	System.out.println("Jar 1");

}

public void method2()

{

	System.out.println("Jar 2");

}

}
public class bike 
{
	 public static void main(String args[])
	 { 
		 Box var1 = new Box();

		 Pill var2 = new Jar();

		 Box var3 = new Cup();

		 Box var4 = new Jar();

		 Object var5 = new Box();

		 Pill var6 = new Pill();
		  var3.method3();
	 }
}
