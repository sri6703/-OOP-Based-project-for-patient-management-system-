package helloworld;
 
public class Demo 
{ 
	int empId; 
	String empName; 
	static String companyName = "TCS"; 
	//static method to valueChange the value of static variable 
	static
	{
		   System.out.println("hello");
	}
	static void valueChange()
	{ 
		   System.out.println("hello 1");
	   companyName = "DataFlair"; 
	} 

	{
		   System.out.println("hello 2");
	}
	//constructor to initialize the variable 
	Demo(int id, String name){ 
	   empId = id; 
	   empName = name; 
	   System.out.println("hello 3");
	} 
	//method to display values 
	void display()
	{
	   System.out.println(empId+" "+empName+" "+companyName);
	} 
	//class to create and display the values of object 
   public static void main(String args[])
      { 
	   
      } 
}