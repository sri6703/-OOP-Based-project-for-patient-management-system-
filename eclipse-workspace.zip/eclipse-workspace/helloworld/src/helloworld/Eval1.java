package helloworld;

import java.util.Scanner;
import java.time.LocalDate;   
class number{
	double real,fractional;
	int integer;
	LocalDate date;
	public number(){
		real=0;
		integer=0;
		fractional=0;
	}
	void readdata(double r) {
		
		real=r;
		integer=(int)real;
		fractional=real-integer;
	}
	void display() {
		 date = LocalDate.now();
		 System.out.println("Today date: "+date);    
		System.out.println("real : "+real);
		System.out.println("integer : "+integer);
		System.out.println("fractional : "+fractional);
	}
}
public class Eval1 {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double r;
		Scanner sc = new Scanner(System.in);
		 number obj = new number();
        String choice="y";
        do {
        	r=sc.nextDouble();
        	obj.readdata(r);
        	obj.display();
        System.out.println("do you want to continue y/n");
         choice=sc.next();
        }
        while(choice=="y" || choice=="Y");
	}
	

}