package helloworld;

import java.util.Scanner;
interface portalinterface
{
	boolean apply();
	void showapplicantdetails();
}
abstract class candidate implements portalinterface
{
    protected int appID;
    protected int cgpa;
    protected String name, city, dob, currentSchool;
    protected String degreeName, University;
    protected boolean isSubmitted = false, isFullTime = true;
    
    candidate()
    {
    	
    }
    candidate(String name,int appID,String city,String dob,int cgpa,String currentSchool,String degreeName,String University)
    {
    	
    }
    public void getter()
    {
    	
    }
    public void setter()
    {
    	
    }
    public String toString()
    {
    	return ;
    }
    public boolean apply() {
    	
    }
	public void showapplicantdetails()
	{
		
	}

}
class doctoral extends candidate
{
	final static String degree_name="PHD";
	 String areaofinterest,facultyofinterest;
	 int researchexperience;
	doctoral()
	{
		 Scanner sc=new Scanner(System.in);
		areaofinterest=sc.nextLine();
		facultyofinterest=sc.nextLine();
		researchexperience=sc.nextInt();
		
	}
	doctoral(String a,int h,String b, String c,int g , String d,String e , String f)
	{
		super(a,h,b,c,g,d,e,f)
	}
	 public String getdoc()
	    {
	    	
	    }
	    public void setdoc()
	    {
	    	
	    }
	    public String toString()
	    {
	    	return ;
	    }
	    public boolean apply() {
	    	
	    }
		public void showapplicantdetails()
		{
			
		}
}
class graduate extends candidate
{
	final static String degree_name="PHD";
	String course,ugmajor;
	int researchpapers=0 , workExperience = 0;
	graduate()
	{
		 Scanner sc=new Scanner(System.in);
		 course=sc.nextLine();
		 ugmajor=sc.nextLine();
		 researchpapers=sc.nextInt();
		 workExperience=sc.nextInt();
		 
		 
	}
	
	 public String getgrad()
	    {
		 String st="true";
		 return st;
	    	
	    }
	    public void setgrad()
	    {
	    	
	    }
	    public void toString()
	    {
	    	
	    }
  public boolean apply() {
	return false;
	    	
	    }
		public void showapplicantdetails()
		{
			
		}
}
class undergraduate extends candidate
{
	final static String degree_name="PHD";
	String majorPreference;
	undergraduate()
	{
		majorPreference=sc.nextLine();
	}
	
	 public void getunder()
	    {
	    	
	    }
	    public void setunder()
	    {
	    	
	    }
	    public void toString()
	    {
	    	
	    }
  public boolean apply() {
	return false;
	    	
	    }
		public void showapplicantdetails()
		{
			
		}
}

public class drriver {
	 public static void main(String args[])
	 { 
	 int ch;
	 String cont = null;
	
	 do
		{
			 System.out.println("enter the choice 1.Add new applicant 2. View applicant details 3.Exit:");
			 Scanner sc=new Scanner(System.in);  
				ch=sc.nextInt();
		if(ch==1)
		{
			  int appID;
			     int cgpa = 0;
			    String name;
				String city;
				String dob;
				 String currentSchool;
			    String degreeName;
				 String University;
	    	System.out.println("eneter the details of the candidate:");
	    	System.out.println("eneter name:");
	    	name=sc.nextLine();
	    	System.out.println("eneter the application id:");
	    	appID=sc.nextInt();
	    	System.out.println("eneter city:");
	    	city=sc.nextLine();
	    	System.out.println("eneter the dob:");
	    	dob=sc.nextLine();
	    	try
	    	{
	    	System.out.println("eneter the cgpa:");
	    	cgpa=sc.nextInt();
	    	}
	    	catch (Exception e )
	    	{
	    		System.out.println("OOPS SOMETHING WENT WRONG!!!!");
	    	}
	    	System.out.println("eneter the current school:");
	    	currentSchool=sc.nextLine();
	    	System.out.println("eneter the degreename:");
	    	degreeName=sc.nextLine();
	    	System.out.println("eneter the university:");
	        University=sc.nextLine();
	        viewcandidatedetails();
			{
				System.out.println("all applicants with the degree name:");
			}
	        System.out.println("enter the choice 1.DOCTORAL 2.GRADUATE 3.UNDERGRADUATE"); 
			int	chi=sc.nextInt();
			if(chi==1)
			{
				System.out.println("enter the no.of students info that has to be entered:");
		    	int n ;
		    	n=sc.nextInt();	
			candidate d= new doctoral();//upcasting 
			doctoral d2[]= new doctoral[n];
				doctoral d1= new doctoral(name,appID,city,dob,cgpa,currentSchool,degreeName,University);
				
				}
			else if (ch==2)
			{
			   
			}
				
				
			
		}
		else if(ch==2)
		{
			
			
		}
		else if(ch==3)
		{
			
		}
		else 
		{
			System.out.println("enter the right choice!!");
		}
		System.out.println("do you want to continue??");
		sc.nextLine();
	      cont=sc.nextLine(); 
		}while(cont.equals("yes")|| cont.equals("y"));
 }

	private static void viewcandidatedetails() {
		// TODO Auto-generated method stub
		
	}

}
