package helloworld;

import java.util.Scanner;
class Address {
	String city=new String();
	String state=new String();
	String country=new String();
	  
	public Address(String city, String state, String country) {  
	    this.city = city;  
	    this.state = state;  
	    this.country = country;  
	}    
	public void dispaddress()
	{
		System.out.println("city:"+this.city);
		System.out.println("state:"+this.state);
		System.out.println("country:"+this.country);
	}
}
class Team
{
	Scanner sc= new Scanner(System.in);  
	String field_name[]=new String[3];
	String s1[]=new String[3];
	String s2[]=new String[3];
	String s3[]=new String[3];
	int score[]=new int[3];
	int age[]=new int[3];
	int wins[]=new int[3];
	int losses[]=new int[3];
	public void get()
	{
		for(int i=0;i<3;i++)
		{
			
		 System.out.println("enter the field name :");
		 field_name[i]= sc.next(); 
		 System.out.println("enter the address as city,state,country :");
		 s1[i]= sc.next(); 
		 s2[i]= sc.next(); 
		 s3[i]= sc.next(); 
		 Address ad=new Address(s1[i],s2[i],s3[i]);  
		 System.out.println("enter score :");
		 score[i]= sc.nextInt(); 
		 System.out.println("enter age :");
		 age[i]= sc.nextInt(); 
		 System.out.println("enter no of wins :");
		 wins[i]= sc.nextInt(); 
		 System.out.println("enter no of  losses:");
		 losses[i]= sc.nextInt(); 
	}
	}
	public void dispw()
	{
	int	max=wins[0];
	int m=0;
	for(int i=1;i<3;i++)
	{
		if(wins[i]>wins[m])
			
		{ 
			max=wins[i];
			m=i;
		}
	}
	System.out.println("details of the team that has won maximum number of times:");
	System.out.println("field name:"+field_name[m]);
	System.out.println("Address:");
	Address add = new Address(s1[m],s2[m],s3[m]);
	add.dispaddress();
	System.out.println("score:"+score[m]);
	System.out.println("age:"+age[m]);
	System.out.println("wins:"+wins[m]);
	System.out.println("losses:"+losses[m]);
		
	}
	public void displ()
	{
	int	min=losses[0];
	int m=0;
	for(int i=1;i<3;i++)
	{
		if(losses[i]>losses[m])
			
		{ 
			min=losses[i];
			m=i;
		}
	}
	System.out.println("details of the team that has won maximum number of times:");
	System.out.println("field name:"+field_name[m]);
	System.out.println("Address:");
	Address add = new Address(s1[m],s2[m],s3[m]);
	add.dispaddress();
	System.out.println("score:"+score[m]);
	System.out.println("age:"+age[m]);
	System.out.println("wins:"+wins[m]);
	System.out.println("losses:"+losses[m]);
		
	}
	
}
public class Sport {
	 public static void main(String args[])
	 { 
	Team t = new Team();
	t.get();
	t.dispw();
	t.displ();
	 }

}
