package helloworld;
import java.lang.Math;
class MyPoint
{
	int x,y;
	MyPoint()
	{
		x=0;
		y=0;
	}
	MyPoint(int x , int y)
	{
		this.x=x;
		this.y=y;
		
	}
	public int getX()
	{
		return x;
	}
	public int getY()
	{
		return y;
	}
	public void setX(int x)
	{
		this.x=x;
	}
	public void setY(int y)
	{
		this.y=y;
	}
	public void setXY(int x , int y)
	{
		this.x=x;
		this.y=y;
	}
	public int[] getXY()
	{
		return new int[] {this.x , this.y};
	}
	public String toString()
	{
		return "("+x+","+y+")";
	}
	public double distance(int x , int y)
	{
		int a , b;
		double c;
		a=this.x-x;
		b=this.y-y;
		c= a*a - b*b;
		return Math.sqrt(c);
		
	}
	public double distance(MyPoint another)
	{
		int a , b;
		double c;
		a=this.x-another.x;
		b=this.y-another.y;
		c= a*a - b*b;
		return Math.sqrt(c);
		
	}
	public double distance()
	{
		int a , b;
		double c;
		a=this.x-0;
		b=this.y-0;
		c= a*a - b*b;
		return Math.sqrt(c);
	}
	}
class MyCircle extends MyPoint
{
	MyPoint center= new MyPoint();
	int radius;
	MyCircle()
	{
		MyPoint c= new MyPoint(0,0);
		 center=c;
		radius=1;
	}
	MyCircle(int x, int y ,int radius)
	{
		center.x=x;
		center.y=y;
		this.radius= radius;
	}
	MyCircle(MyPoint a, int radius)
	{
		center.x=a.x;
		center.y=a.y;
		this.radius=radius;
	}
	public int getradius()
	{
		return radius;
	}
	public void setradius(int radius)
	{
		this.radius=radius;
	}
	public MyPoint getcenter()
	{
		return center;
	}
	public void setcenter(MyPoint center)
	{
		this.center.x=center.x;
		this.center.y=center.y;
	}
	public int getcenterx()
	{
		return center.x;
	}
	public void setcenterx(int x)
	{
		center.x=x;
	}
	public int getcentery()
	{
		return center.y;
	}
	public void setcentery(int y)
	{
		center.y=y;
	}
	public int[] getcenterxy()
	{
		return new int[] {center.x,center.y};
	}
	public void setcenterxy(int x, int y)
	{
		center.x=x;
		center.y=y;
	}
	public String toString()
	{
		return "MyCircle[radius="+radius+",center=("+center.x+","+center.y+")]";
		
	}
	public double getarea()
	{
		return 3.14*radius*radius;
	}
	public double getcircumference()
	{
		return 3.14*2*radius;
	}
	public double distancee(MyCircle another)
	{
		MyPoint p= new MyPoint();
		p.x=another.center.x;
		p.y=another.center.y;
		double d;
		d=p.distance(center.x,center.y);
		return d;
	}
}
public class Oopassign
{
	 public static void main(String args[])
	 { 
		 
	 }
	 
}
