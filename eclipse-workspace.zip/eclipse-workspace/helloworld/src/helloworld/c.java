package helloworld;

import java.util.*;
import java.util.*;

public class c {

              public static void main(String[] args) {

                 List<String> al1 = new ArrayList<String>();

                 al1.add("A");

                 al1.add("B");


                 List<String> al2 = new ArrayList<String>();

                 al2.add("P");

                 al2.add("Q");


                 al1.addAll(0, al2);

                 System.out.println(al1);

              }

           }