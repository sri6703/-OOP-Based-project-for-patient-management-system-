package helloworld;

public class StudentDemo {
	public static void main(String args[])
    {  
          Sstudent s1 = new Sstudent();  
          s1.showData(); 
         Sstudent s2 = new Sstudent();  
         s2.showData(); 
     }
}
