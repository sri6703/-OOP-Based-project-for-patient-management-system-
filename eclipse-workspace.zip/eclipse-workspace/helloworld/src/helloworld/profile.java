package helloworld;

public class profile

{

public static int recur(int count, int n)

{

int newCount = count;

if (n >= 1)

{


newCount++;  System.out.println(newCount + "" + n + " "); // line B: increment, print
newCount = recur(newCount, n-1); // line A: recur


newCount = recur(newCount, n-1); // line C: recur

}

return newCount;

}

public static void main(String[] args)

{

recur(0, 3);

System.out.println();

}

}