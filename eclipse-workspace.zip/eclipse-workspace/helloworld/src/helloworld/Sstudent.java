package helloworld;

public class Sstudent {
	int a; //initialized to zero 
   static int b;//initialized to zero only when class is loaded
    static 
    {
    	b++;
    }
    Sstudent() //Constructor incrementing static variable b
     {   b++;  } 
     public void showData()
     { System.out.println("Value of a = "+a); 
       System.out.println("Value of b = "+b); 
     }
}
