package helloworld;

import java.util.Scanner;

abstract class taxi
{
	int reg_no,max;
    float price ;
	String brand,model,fueltype,dname;
	abstract void showdetails();
	void tostring()
	{
		System.out.println("taxi:");
		System.out.println("driver name:"+dname);
		System.out.println("model:"+model);
		System.out.println("price:"+price);
		System.out.println("fueltype:"+fueltype);
		System.out.println("brand:"+brand);
		System.out.println("registration no:"+reg_no);
		System.out.println("maximum passenger count:"+max);
	}
}
class suv extends taxi
{
	private final static float mprice =14;
	private final static int mmax=7;
    
	void showdetails()
	{
		System.out.println("maximum price per kilometer:"+mprice);
		System.out.println("maximum passenger allowed:"+mmax);
		this.check();
	}
	void check()
	{
		if(mmax<max)
		{
			System.out.println("do not abide by rules");
		}
		else 
			System.out.println("abiding by rules");
	}
	void getdetails()
	{
		System.out.println("enter the taxi details");
		Scanner sc=new Scanner(System.in);  
		System.out.println("driver name:");
		dname=sc.nextLine();
		System.out.println("brand:");
		brand=sc.nextLine();
		System.out.println("model:");
		model=sc.nextLine();
		System.out.println("fueltype:");
		fueltype=sc.nextLine();
		System.out.println("price:");
		price=sc.nextFloat();
		System.out.println("registration no:");
		reg_no=sc.nextInt();
		System.out.println("maximum head count:");
		max=sc.nextInt();
	}
	void tostring()
	{
		System.out.println("taxi:");
		System.out.println("driver name:"+dname);
		System.out.println("model:"+model);
		System.out.println("price:"+price);
		System.out.println("fueltype:"+fueltype);
		System.out.println("brand:"+brand);
		System.out.println("registration no:"+reg_no);
		System.out.println("maximum passenger count:"+max);
	}
	
}
class sedan extends taxi

{
	private final static float mprice =11;
	private final static int mmax=4;
	void showdetails()
	{
		System.out.println("maximum price per kilometer:"+mprice);
		System.out.println("maximum passenger allowed:"+mmax);
	    this.check();
	}
	void getdetails()
	{
		System.out.println("enter the taxi details");
		Scanner sc=new Scanner(System.in);  
		System.out.println("driver name:");
		dname=sc.nextLine();
		System.out.println("brand:");
		brand=sc.nextLine();
		System.out.println("model:");
		model=sc.nextLine();
		System.out.println("fueltype:");
		fueltype=sc.nextLine();
		System.out.println("price:");
		price=sc.nextFloat();
		System.out.println("registration no:");
		reg_no=sc.nextInt();
		System.out.println("maximum head count:");
		max=sc.nextInt();
	}
	void check()
	{
		if(mmax<max)
		{
			System.out.println("do not abide by rules");
		}
		else 
			System.out.println("abiding by rules");
	}
void tostring()
{
	System.out.println("taxi:");
	System.out.println("driver name:"+dname);
	System.out.println("model:"+model);
	System.out.println("price:"+price);
	System.out.println("fueltype:"+fueltype);
	System.out.println("brand:"+brand);
	System.out.println("registration no:"+reg_no);
	System.out.println("maximum passenger count:"+max);
}
	
}
class hatchback extends taxi
{
	private final static float mprice =8;
	private final static int mmax=4;
	void showdetails()
	{
		System.out.println("maximum price per kilometer:"+mprice);
		System.out.println("maximum passenger allowed:"+mmax);
		 this.check();
	}
	void getdetails()
	{
		System.out.println("enter the taxi details");
		Scanner sc=new Scanner(System.in);  
		System.out.println("driver name:");
		dname=sc.nextLine();
		System.out.println("brand:");
		brand=sc.nextLine();
		System.out.println("model:");
		model=sc.nextLine();
		System.out.println("fueltype:");
		fueltype=sc.nextLine();
		System.out.println("price:");
		price=sc.nextFloat();
		System.out.println("registration no:");
		reg_no=sc.nextInt();
		System.out.println("maximum head count:");
		max=sc.nextInt();
	}
	void check()
	{
		if(mmax<max)
		{
			System.out.println("do not abide by rules");
		}
		else 
			System.out.println("abiding by rules");
	}
void tostring()
{
	System.out.println("taxi:");
	System.out.println("driver name:"+dname);
	System.out.println("model:"+model);
	System.out.println("price:"+price);
	System.out.println("fueltype:"+fueltype);
	System.out.println("brand:"+brand);
	System.out.println("registration no:"+reg_no);
	System.out.println("maximum passenger count:"+max);
}
	
}
public class driver
{
	 public static void main(String args[])
	 { 
		 int ch;
		 String cont = null;
		 do
			{
				 System.out.println("enter the choice 1.SUV 2.SEDEN 3.HATCHBACK:");
				 Scanner sc=new Scanner(System.in);  
					ch=sc.nextInt();
			if(ch==1)
			{
				suv t=new suv();
				taxi s=new suv();
				t.getdetails();
				s.showdetails();
				t.tostring();
				
			}
			else if(ch==2)
			{
				sedan t=new sedan();
				taxi s=new sedan();
				t.getdetails();
				s.showdetails();
				t.tostring();
				
			}
			else if(ch==3)
			{
				hatchback t=new hatchback();
				taxi s=new hatchback();
				t.getdetails();
				s.showdetails();
				t.tostring();
				
			}
			else 
			{
				System.out.println("enter the right choice!!");
			}
			System.out.println("do you want to continue??");
			sc.nextLine();
		      cont=sc.nextLine(); 
			}while(cont.equals("yes")|| cont.equals("y"));
	 }
}
