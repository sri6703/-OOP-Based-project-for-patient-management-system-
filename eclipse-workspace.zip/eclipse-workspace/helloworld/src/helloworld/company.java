package helloworld;
interface ftecompany
{
	void addctec();
	void addcontract();
	void position();
}
interface interncompany
{
	void addstipend();
	void addduration();
}

class amazon implements interncompany
{
     static float total_package;
	public void addstipend() {
		
		
	}


	public void addduration() {
	
		
	}
	
}
class pwc implements interncompany,ftecompany
{

	 static float total_package;
	
	public void addctec() {
		
		
	}

	
	public void addcontract() {
		
		
	}

	
	public void position() {
		
		
	}


	
	public void addstipend() {
		
		
	}



	public void addduration() {
		
		
	}
	
}
class increff implements ftecompany
{

	 static float total_package;
	
	public void addctec() {
		
		
	}

	
	public void addcontract() {
	
		
	}

	
	public void position() {
		
		
	}
	
}

public class company {
	static void main(String arg[])
	{
		
	}

}
