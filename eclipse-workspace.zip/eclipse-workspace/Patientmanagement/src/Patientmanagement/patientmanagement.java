package Patientmanagement ;


import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
interface  hospital  // interface
{ 
	void getdetails();
	void display();
}
class patient implements hospital  // class
{
	 String pid, pname, disease, sex, admit_status;
	    int age;
		
		public void getdetails()                                                          //AGGREGATION - INHERITANCE (HAS A RELATION)
		{
			 Scanner input = new Scanner(System.in);
		        System.out.print("id:-");
		        pid = input.nextLine();
		        System.out.print("name:-");
		        pname = input.nextLine();
		        System.out.print("disease:-");
		        disease = input.nextLine();
		        System.out.print("sex:-");
		        sex = input.nextLine();
		        System.out.print("admit_status:-");
		        admit_status = input.nextLine();
		        System.out.print("age:-");
		        age = input.nextInt();
		        
		        
		}
	
		public void display() {
			
			System.out.println(this.pid + "\t" + this.pname + " \t" + this.disease + "     \t" + this.sex + "      \t" + this.admit_status + "\t" + this.age);
			
		}
}
class doctor implements hospital
{
	 String did, dname, specilist, appoint, doc_qual;
	    int droom;
		
	    
		public void getdetails() 
		{
			 Scanner input = new Scanner(System.in);
		        System.out.print("id:-");
		        did = input.nextLine();
		        System.out.print("name:-");                                                     //AGGREGATION - INHERITANCE (HAS A RELATION)
		        dname = input.nextLine();
		        System.out.print("specilization:-");
		        specilist = input.nextLine();
		        System.out.print("work time:-");
		        appoint = input.nextLine();
		        System.out.print("qualification:-");
		        doc_qual = input.nextLine();
		        System.out.print("room no.:-");
		        droom = input.nextInt();
			
		}
		
		public void display() {
			 
			System.out.println(this.did + "\t" + this.dname + "  \t" + this.specilist + "     \t" + this.appoint + "    \t" + this.doc_qual + "       \t" + this.droom);
			
		}
	
	
	
}
class staff implements hospital
{
	String sid, sname, desg, sex;
    int salary;
    
	public void getdetails()
	{
		 Scanner input = new Scanner(System.in);
	        System.out.print("id:-");
	        sid = input.nextLine();                                             
	        System.out.print("name:-");
	        sname = input.nextLine();
	        System.out.print("desigination:-");
	        desg = input.nextLine();
	        System.out.print("sex:-");
	        sex = input.nextLine();
	        System.out.print("salary:-");
	        salary = input.nextInt();
	}
	
	public void display() {
		
		System.out.println(this.sid + "\t" + this.sname + "\t" + this.sex + "\t" + this.salary);
		
	}
}
class medicines implements hospital
{
	 String med_name,med_comp,med_exp;
	 double med_cost;
	 int count;
	    int age;
		
		public void getdetails()
		{
			 Scanner input = new Scanner(System.in);		       
		        System.out.print("medicine name:-");
		        med_name = input.nextLine();
		        System.out.print("medicine company:-");
		        med_comp = input.nextLine();
		        System.out.print("medicine expiry date:-");
		        med_exp = input.nextLine();
		        System.out.print("cost:-");
		        med_cost = input.nextDouble();
		        System.out.print("count:-");
		        count = input.nextInt();
		        
		        
		}
	
		public void display() {
			
			System.out.println(this.med_name + "\t" + this.med_comp + " \t" + this.med_exp + "     \t" + this.med_cost + "      \t" + this.count );
			
		}
}
class Appointment extends patient implements hospital {
	
	 String pid;
	 String pname;
	String disease;
	String dname;
	String date;
	String time;
	
public void getdetails(ArrayList<patient> pat , ArrayList<Appointment> ap,int j ) {
	
	Scanner input = new Scanner(System.in);
    int ch=1;
    while(ch==1)
    {
    	Appointment a = ap.get(j); 
    	System.out.println("patient id:-");
        pid = input.nextLine();
    for(int i=0;i<pat.size()&&ch==1;i++)
        {
        	 patient p1 = pat.get(i); 
        	 if(p1.pid.equals(this.pid))
             {
                  	pname=p1.pname;
                	ch=0;
                	break;
            }
        }
    if (ch==1)
    {
    	System.out.println("Enter a valid patient id");
    }
    }
    ch=0;
      do
      {
    	  System.out.println("Disease:-(fever/dengue/cancer/heart)");
    	    disease = input.nextLine();
    switch(disease) {
    
    case "fever":  dname = "Dr.R.Sarathi";
    break;
    case "dengue":  dname = "Dr. K . Rathnam";
    break;
    case "cancer":  dname = "Dr.M.Poonguzhalili";
    break;
    case "heart":  dname = "Dr.S. Smrithi";
    break;
    default :  System.out.println("Enter a valid disease!! , Enter again !");
               ch=1;
    }
      }while(ch==1);
    System.out.println("date:-");
    date = input.nextLine();
    System.out.println("time:-");
    time = input.nextLine();
}
public void display(ArrayList<Appointment> a,int k) {
	    Appointment ai = a.get(k); 
		
		System.out.println(ai.pid+ "\t" + ai.pname + "\t" + ai.disease+ "\t" + ai.dname+ "\t" + ai.date+ "\t" + ai.time);
	}
	
}
class Prescription extends patient implements hospital
{
	
	 String ppid;
	 String pid;
	 String pname;
	 String mname;
	 int mno, mcost;
	 int mtotal;
	
	public void getdetails(ArrayList<patient> pat , ArrayList<Prescription> p,int j )
	{
		Scanner input = new Scanner(System.in);
		int ch=1;
		System.out.println("prescription id:-");
		ppid = input.nextLine();
        while(ch==1)
        {
        	Prescription pr = p.get(j); 
        	System.out.println("patient id:-");
            pid = input.nextLine();
        for(int i=0;i<pat.size()&&ch==1;i++)
            {
            	 patient p1 = pat.get(i); 
            	 if(pr.pid.equals(this.pid))
                 {
                      	pname=p1.pname;
                    	ch=0;
                    	break;
                }
            }
        if (ch==1)
        {
        	System.out.println("Enter a valid patient id");
        }
        }
        System.out.println("medicine name:-");
		mname = input.nextLine();
		System.out.println("quantity:-");
		mno = input.nextInt();
		System.out.println("cost:-");
		mcost = input.nextInt();
		
		mtotal = mno*mcost;
	}
	
public void display(ArrayList<Prescription> a,int k) {
	
	
   Prescription ai = a.get(k); 
    System.out.println(ai.ppid+ "\t" + ai.pname + "\t" + ai.mname+ "\t" + ai.mno+ "\t" + ai.mcost+ "\t" + ai.mtotal);
	}
}

class Billing extends Prescription implements hospital
{
	
	String bid;
	 String pid;
	 String ppid;
	int cfee;
	 int mtotal;
	int btotal;
	
	public void getdetails( ArrayList<Billing>bi,int j,ArrayList<Prescription> pr ) {
		
		cfee = 200;
		int ch=1;
		Scanner input = new Scanner(System.in);
		System.out.println("bill id:-");
		bid = input.nextLine();
		while(ch==1)
        {
        	Billing bil = bi.get(j); 
        	System.out.println("patient id:-");
            pid = input.nextLine();
        for(int i=0;i<pr.size()&&ch==1;i++)
            {
            	 Prescription p1 = pr.get(i); 
            	 if(p1.pid.equals(this.pid))
                 {
            		 bil.ppid = p1.ppid;
                 	bil.mtotal = p1.mtotal;
                 	 bil.btotal = bil.cfee + bil.mtotal;
                    	ch=0;
                    	break;
                }
            }
        if (ch==1)
        {
        	System.out.println("Enter a valid patient id");
        }
        }
		
	}
	
	public void display(int k,ArrayList<Billing> bi) {
		 Billing b = bi.get(k); 
		System.out.println(b.bid+ "\t" + b.pid + "\t" + b.ppid+ "\t" + b.cfee+ "\t" + b.mtotal+ "\t" + b.btotal);

	}
}

public class patientmanagement {

	public static void main(String[] args) 
	{
         ArrayList<patient> p = new ArrayList<patient>();   
		 ArrayList<staff> s = new ArrayList<staff>();
		 ArrayList<doctor> d = new ArrayList<doctor>();
		 ArrayList<medicines> m = new ArrayList<medicines>();
		 ArrayList<Appointment> a = new ArrayList<Appointment>(); 
		 ArrayList<Prescription> pr = new ArrayList<Prescription>();                               //ARRAY LIST
		 ArrayList<Billing> b = new ArrayList<Billing>();
		  
		 
		 
		 
		Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1,s7=0, s8=0, ctd=0,ctp=0,cts=0,ctm=0,cta=0,ctpr=0,ctb=0,z=0,z1=0,z2=0;
        
        while (status == 1)                                                                           //MENUE DRIVEN PROGRAM
        {
        	
            System.out.println("\n                                    MAIN MENU");
            System.out.println("-----------------------------------------------------------------------------------");
            System.out.println("1.Doctors  2. Patients  3.Staff  4.Medicines  5.Appointment  6.Prescription   7.Billing   8.Vaccination");
            System.out.println("-----------------------------------------------------------------------------------");
            choice = input.nextInt();
            switch (choice)
            {
                case 1:
                    {
                        System.out.println("--------------------------------------------------------------------------------");
                        System.out.println("                      **DOCTOR SECTION**");
                        System.out.println("--------------------------------------------------------------------------------");
                        s1 = 1;
                        while (s1 == 1)
                        {
                            System.out.println("1.Add New Entry\n2.automatically use already existing data\n3.Existing Doctors List");
                            c1 = input.nextInt();
                            switch (c1)
                            {
                            
                                case 1:
                                    {
                                    	
                                        d.add(new doctor());
                                        for (int i=ctd ; i<d.size();i++)
                                        {
                                        	 doctor d1 = d.get(i);  
                                        	 d1.getdetails();
                                        	 ctd++;                                            
                                                                             }
                                    	
                                    	break;
                                    }
                                    
                                case 2:
                                 {
	                               String strLine = "";  
                        	        
                        	        try {
                        	             BufferedReader br = new BufferedReader(new FileReader("C://Users//Srinithi//Downloads/doctor.txt"));
                        	             while (strLine != null) 
                        	            {
                        	            	
                       	            	 for (int k=ctd ; k<5+ctd;k++)                       //FILE HANDLING
                              	              {
                        	                     
                        	                if(strLine == null)
                        	                	break;
                          	                d.add(new doctor()); 
                        	                doctor d1 = d.get(k); 
                        	                strLine = br.readLine();	
                        	                if(strLine!=null)
                        	                d1.did = strLine;
                        	            
                        	                strLine = br.readLine();
                        	                if(strLine!=null)                                      // EXCEPTION IE TRY AND CATCH
                        	               	d1.dname=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	               	d1.specilist=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	                d1.appoint=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	               	d1.doc_qual=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)                            	              
                        	               	d1.droom=Integer.valueOf(strLine);  
                        	                strLine = br.readLine();
                        	                 
                        	     		 }
                        	               
                        	             }
                        	            
                        	             System.out.println("enabled!!");
                        	            
                        	             br.close();
                        	        }
                        	        
										catch (FileNotFoundException e) {
                        	            System.err.println("File not found");
                        	        } catch (IOException e) {
                        	            System.err.println("Unable to read the file.");
                        	        }
                        	        int h=d.size()-1;
                        	        d.remove(h);
                        	        int ch=0;
                        	        for (int i=ctd ; i<d.size();i++)
                                    {
                                    	 doctor d1 = d.get(i); 
                                    	 if(ch==0)
                                    	 {
                                    		 ch=1;
                                    	 d1.did="d01";
                                    	 d1.dname="DR.Poonguzhali";
                                    	 d1.specilist="Anaesthesiology";
                                    	 }
                                    	 d1.display();
                                    }
                        	        ctd+=5;
                                }
                                 break; 
                                case 3:
                                    {
                                        System.out.println("--------------------------------------------------------------------------------");
                                        System.out.println("id \t Name\t Specilist \t Timing \t Qualification \t Room No.");
                                        System.out.println("--------------------------------------------------------------------------------");
                                        
                                        for (int i=0 ; i<d.size();i++)
                                        {
                                        	 doctor d1 = d.get(i);  
                                        	 d1.display();
                                        }
                                     }
                                    
                                
                                	
                            }
                            System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                            s1 = input.nextInt();
                        }
                        break;
                        }
                case 2:
                    {
                        System.out.println("--------------------------------------------------------------------------------");
                        System.out.println("                     **PATIENT SECTION**");
                        System.out.println("--------------------------------------------------------------------------------");
                        s2 = 1;
                       while (s2 == 1)
                        {
                        	
                            System.out.println("1.Add New Entry\n2.automatically use already existing data\n3.Existing Patients List");
                            c1 = input.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                    	  p.add(new patient());
                                    	 
                                          for (int i=ctp ; i<p.size();i++)
                                          {
                                          	 patient p1 = p.get(i);  
                                          	 p1.getdetails();
                                          	 ctp++;                                            
                                   }
                                      	
                                      	break;
     
                                    }
                                case 2:
                                {
                         			
                        	        String strLine = "";  
                        	        
                        	        try {
                        	             BufferedReader br = new BufferedReader(new FileReader("C://Users//Srinithi//Downloads/patient.txt"));
                        	             while (strLine != null) 
                        	            {
                       	            	 for (int k=ctp ; k<5+ctp;k++)
                              	              {
                        	                     
                        	                if(strLine == null)                                             //FILE HANDLING
                        	                	break;
                          	                p.add(new patient()); 
                        	                patient p1 = p.get(k); 
                        	                strLine = br.readLine();	
                        	                if(strLine!=null)
                        	                p1.pid = strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	                p1.pname=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	                p1.disease=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	                p1.sex=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)
                        	                p1.admit_status=strLine;
                        	                strLine = br.readLine();
                        	                if(strLine!=null)                            	              
                        	                p1.age=Integer.valueOf(strLine);              //TYPE CASETING FROM STRING TO INTEGER
                        	                strLine = br.readLine();
                        	                 
                        	     		 }
                        	               
                        	             }
                        	             ctp+=5;
                        	            
                        	             System.out.println("enabled!!");
                        	             br.close();
                        	        }
                        	        
										catch (FileNotFoundException e) {
                        	            System.err.println("File not found");
                        	        } catch (IOException e) {
                        	            System.err.println("Unable to read the file.");
                        	        }
                        	        int h=p.size()-1;
                        	        p.remove(h);
                                }
                                break;
                                case 3:
                                    {
                                       
                            			
                                        
                            	        System.out.println("--------------------------------------------------------------------------------");
                                        System.out.println("id \t Name \t Disease \t Gender \t Admit Status \t Age");
                                        System.out.println("--------------------------------------------------------------------------------");                                                        	
                                        
                                       
                                       
                                   	 
                                        for (int i=0 ; i<p.size();i++)
                                        {
                                        	patient p1 = p.get(i); 
                                        	 p1.display();
                                        }
                                      
                                    }
                            }
                            System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                            s2 = input.nextInt();
                        }
                        break;
                    }
                case 3:
                {
                    s3 = 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                       **STAFF SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s3 == 1)
                    {
                        String an = "nurse", bw = "worker", c = "security";
                        System.out.println("1.Add New Entry \n2.automatically use already existing data\n3.Existing Nurses List\n4.Existing Workers List \n5.Existing Security List");
                        c1 = input.nextInt();
                       
                        switch (c1)
                        {
                            case 1:
                                {
                                	s.add(new staff());
                                    for (int i=cts ; i<s.size();i++)
                                    {
                                    	 staff st = s.get(i);  
                                    	 st.getdetails();
                                    	 cts++;                                            
                                         }
                                    break;
                                }
                            case 2:
                            {
                            	
                     			int ch=0;
                     			if(ch==1)
                     				continue;
                     			else
                     			{
                    	        String strLine = "";  
                    	        
                    	        try {
                    	             BufferedReader br = new BufferedReader(new FileReader("C://Users//Srinithi//Downloads/staff.txt"));
                    	             while (strLine != null) 
                    	            {
                   	            	 for (int k=cts ; k<5+cts;k++)
                          	              {
                    	                     
                    	                if(strLine == null)
                    	                	break;
                      	                s.add(new staff()); 
                    	                staff st = s.get(k); 
                    	                strLine = br.readLine();	                                        //FILE HANDLING
                    	                if(strLine!=null)
                    	                st.sid = strLine;
                    	                strLine = br.readLine();
                    	                if(strLine!=null)
                    	                st.sname=strLine;
                    	                strLine = br.readLine();
                    	                if(strLine!=null)
                    	                st.desg=strLine;
                    	                strLine = br.readLine();
                    	                if(strLine!=null)
                    	                st.sex=strLine;
                    	                strLine = br.readLine();                    	              
                    	                if(strLine!=null)                            	              
                    	                st.salary=Integer.valueOf(strLine);                           //TYPE CASETING FROM STRING TO INTEGER
                    	                strLine = br.readLine();
                    	                 
                    	     		 }
                    	               
                    	             }
                    	            
                    	             
                    	             System.out.println("enabled!!");
                    	             br.close();
                    	        }
                    	        
									catch (FileNotFoundException e) {
                    	            System.err.println("File not found");
                    	        } catch (IOException e) {
                    	            System.err.println("Unable to read the file.");
                    	        }                    	                          	        
                                   }
                     			
                     			 int h=s.size()-1;
                	             s.remove(h); 
                	             int ch1=0;
                	             for (int i=ctd ; i<s.size();i++)
                                 {
                                 	staff st = s.get(i); 
                                 	if(ch==0)
                                 	{ch1=1;
                                 		st.sid="S01";
                                 		st.sname="R.Rathna";
                                 		st.desg="nurse";
                                 	}
                                 	 st.display();
                                 }
                	             ctd+=5;
                            }
                            break;
                            case 3:
                                {
                                    System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("id \t Name \t Gender \t Salary");
                                    System.out.println("--------------------------------------------------------------------------------");
                                   
                                    for (int i=0 ; i<s.size();i++)
                                    {
                                    	staff st = s.get(i); 
                                    	if (an.equals(st.desg))
                                    	 st.display();
                                    }
                                    break;
                                }
                                
                            case 4:
                                {
                                    System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("id \t Name \t Gender \t Salary");
                                    System.out.println("--------------------------------------------------------------------------------");
                                    

                                    for (int i=0 ; i<s.size();i++)
                                    {
                                    	staff st = s.get(i); 
                                    	if (bw.equals(st.desg))
                                    	 st.display();
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("id \t Name \t Gender \t Salary");
                                    System.out.println("--------------------------------------------------------------------------------");
                                    for (int i=0 ; i<s.size();i++)
                                    {
                                    	staff st = s.get(i); 
                                    	if (c.equals(st.desg))
                                    	 st.display();
                                    }
                                    break;
                                }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s3 = input.nextInt();
                    }
                    break;
                }
                case 4:
                {
                    s4 = 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                     **MEDICINE SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s4== 1)
                    {
                        System.out.println("1.Add New Entry\n2.automatically use already existing data\n3. Existing Medicines List");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                                {
                                	
                                	m.add(new medicines());
                                    for (int i=ctm ; i<m.size();i++)
                                    {
                                    	 medicines m1 = m.get(i);  
                                    	 m1.getdetails();
                                    	 ctm++;                                            
                                         }
                                    break;
                                }
                            case 2:
                            {
                            	int ch=0;
                     			if(ch==1)
                     				continue;
                     			else
                     			{
                    	        String strLine = "";  
                    	        
                    	        try {
                    	             BufferedReader br = new BufferedReader(new FileReader("C://Users//Srinithi//Downloads/medicines.txt"));
                    	             while (strLine != null) 
                    	            {
                   	            	 for (int k=ctm ; k<ctm+5;k++)
                          	              {
                    	                     
                    	                if(strLine == null)
                    	                	break;
                      	                m.add(new medicines()); 
                    	                medicines mt = m.get(k); 
                    	                strLine = br.readLine();	                                         //FILE HANDLING
                    	                if(strLine!=null)
                    	                mt.med_name = strLine;
                    	                strLine = br.readLine();
                    	                if(strLine!=null)
                    	                mt.med_comp=strLine;
                    	                strLine = br.readLine();
                    	                if(strLine!=null)
                    	                mt.med_exp=strLine;
                    	                strLine = br.readLine();
                    	                if(strLine!=null)
                    	                mt.med_cost=Double.valueOf(strLine); 
                    	                strLine = br.readLine();                    	              
                    	                if(strLine!=null)                            	              
                    	                mt.count=Integer.valueOf(strLine);  
                    	                strLine = br.readLine();
                    	                 
                    	     		 }
                    	               
                    	             }
                    	             for (int i=ctm ; i<m.size();i++)
                                     {
                                     	medicines mt = m.get(i); 
                                     	
                                     	 mt.display();
                                     }
                    	             ctm+=5;                    	             
                    	             System.out.println("enabled!!");
                    	             br.close();
                    	        }
                    	        
									catch (FileNotFoundException e) {
                    	            System.err.println("File not found");
                    	        } catch (IOException e) {
                    	            System.err.println("Unable to read the file.");
                    	        }                    	                          	        
                                   }
                     			
                     			
                	             
                            
                            break;
                            }
                            case 3:
                                {
                                    System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("Name \t Company \t Expiry Date \t Cost\t\t\t Count");
                                    System.out.println("--------------------------------------------------------------------------------");
                                    for (int i=0 ; i<m.size();i++)
                                    {
                                    	medicines mt = m.get(i);                                     	
                                    	 mt.display();
                                    }
                                    break;
                                }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s4 = input.nextInt();
                    }
                    break;
                }
                case 5:
                {
                    s5= 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                    **APPOINTMENT SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s5 == 1)
                    {
                        System.out.println("1.Add New Entry \n2. Appointment List");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                                {
                                	a.add(new Appointment());                               	                                   
                                    	 Appointment a1 = a.get(cta);  
                                       	 a1.getdetails(p,a,z);                                    	 
                                         cta++;
                                         z++;
                                    break;
                                }
                            case 2:
                                {
                                	System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("Patient id \t Patient Name \t Disease \t Doctor Name \t Date \t  Time");
                                    System.out.println("--------------------------------------------------------------------------------");
                                    for (int i=0 ; i<a.size();i++)
                                    {
                                    	Appointment ap = a.get(i); 
                                    	
                                    	 ap.display(a,i);
                                    }
                                    break;
                                }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s5 = input.nextInt();
                    }
                    break;
                }
                case 6:
                {
                    s6= 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                    **PRESCRIPTION SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s6 == 1)
                    {
                        System.out.println("1.Add New Entry \n2. Prescription List");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                                {
                                	pr.add(new Prescription());                               	                                   
                                    	 Prescription prr = pr.get(ctpr);  
                                       	 prr.getdetails(p,pr,z1);                                    	 
                                         ctpr++;
                                         z1++;
                                    break;
                                }
                            case 2:
                                {
                                	System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("Prescription id \t Patient Name \t Medicine Name \t Quantity \t Cost \t Total cost ");
                                   System.out.println("--------------------------------------------------------------------------------");	
                                    for (int i=0 ; i<pr.size();i++)
                                    {
                                    	Prescription pres = pr.get(i); 
                                    	
                                    	 pres.display(pr,i);
                                    }
                                    break;
                                }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s6 = input.nextInt();
                    }
                    break;
                }
                case 7:
                {
                    s7= 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                    **BILLING SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s7 == 1)
                    {
                        System.out.println("1.Add New Entry \n2. BILLING List");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                                {
                                	b.add(new Billing());                               	                                   
                                	Billing bi = b.get(ctb);  
                                       	 bi.getdetails(b,z2,pr);                                    	 
                                         ctb++;
                                         z2++;
                                    break;
                                }
                            case 2:
                                {
                                	System.out.println("--------------------------------------------------------------------------------");
                            	    System.out.println("Bill id \t Patient id \t Prescription id \t Consultation fee \t Medicine cost \t Total Bill");
                            	    System.out.println("--------------------------------------------------------------------------------");	
                                    for (int i=0 ; i<b.size();i++)
                                    {
                                    	Billing bii = b.get(i); 
                                    	
                                    	 bii.display(i,b);
                                    }
                                    break;
                                }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s7 = input.nextInt();
                    }
                    break;
                }
                
                case 8:
                {
                	s8= 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                    **VACCINATION SECTION TO CHECK ELIGIBILITY**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s8 == 1)
                    { 	
                            	covid19 c = new vaccination();                                     // UPCASTING
                            	 int age ,daysgap,dose = 0;
                            	 System.out.println("enter your age !!");
                        		 age = input.nextInt();
                        		 if(age<18)
                        			 c.assign(age);
                        		 if(age>=18)
                        		 {
                        		 System.out.println("enter your dose number (0 or 1) !!");		 
                        		 dose = input.nextInt();
                        		 if(dose!=1)
                        		 c.assign(age, dose);
                        		 }
                        		 if(dose==1)
                        		 {
                        		 System.out.println("enter your days after vaccine dose 1: !!");
                        		 daysgap = input.nextInt();
                        		 c.assign(age, daysgap, dose);
                        		 }
                        		 
                            	c.display();
                            	
                            	 System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                                 s8= input.nextInt();
                    }
                    
                }
                 break;
               default:
                    {
                        System.out.println(" You Have Enter Wrong Choice!!!");
                    }
            }
            System.out.println("\nReturn to MAIN MENU Press 1");
            status = input.nextInt();
        }

		}

	

}
