package Patientmanagement;

import java.util.Scanner;

abstract class covid19{                                                   // ABSTRACT CLASS
	
	protected int age;
	protected int daysgap;
	protected int dose;
abstract void display();
abstract void assign(int age, int daysgap, int dose);
abstract void assign(int age);
abstract void assign(int age ,int dose);
}


public class vaccination extends covid19
{
	Scanner input = new Scanner(System.in);
    static String vaccinename;                                                     //STATIC VARIABLE VACCINENAME
	vaccination()
	{
		System.out.println("enter the vaccine u wish to get vaccinated with");
		vaccinename=input.nextLine();                                                //CONSTRUCTOR
		
	}
	public int getDose() {
		return dose;
	}
public void setDose(int dose) {
		this.dose = dose;
	}
	public int getDaysgap() {
		return daysgap;
	}
                                                                                                //ACCESSORS AND MUTATORS - GET AND SET FUNCTIONS
	public void setDaysgap(int daysgap) {
		this.daysgap = daysgap;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
		
	
	@Override
	void display() {                                                    // OVERRIDING OF FUNCTION DISPLAY
		if(getAge()>=18)
		System.out.println("U ARE ELIGIBLE TO GET VACCINATED WITH "+vaccinename);
		else if (getDose()==1)
			{if(getDaysgap()>45)
			System.out.println("U ARE  ELIGIBLE TO GET VACCINATED "+vaccinename);
			}
			else 
				System.out.println("U ARE NOT ELIGIBLE TO GET VACCINATED "+vaccinename);
	}
	@Override                                                 
	void assign(int age , int daysgap,int dose) {
		setAge( age);
		setDose(dose);
		setDaysgap(daysgap);                                    //OVERLOADING OF FUNCTION ASSIGN
		
	}
	void assign(int age)
	{
		setAge( age);
	}
	void assign(int age ,int dose)
	{
		setAge( age);
		setDose(dose);
	}
}
