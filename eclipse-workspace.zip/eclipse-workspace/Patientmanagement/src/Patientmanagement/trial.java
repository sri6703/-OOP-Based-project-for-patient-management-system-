package Patientmanagement;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class trial {

	public static void main(String[] args) {
		
		StringBuilder sb = new StringBuilder();
        String strLine = "";
        String[] str_data1= new String[3];
        String[] str_data2= new String[3];
        String[] str_data3= new String[3];
        String[] str_data4= new String[3];
        String[] str_data5= new String[3];
        String[] str_data6= new String[3];
        for(int i=0;i<3;i++)
        {
        	str_data1[i]= "";
        	str_data2[i]= "";
        	str_data3[i]= "";
        	str_data4[i]= "";
        	str_data5[i]= "";
        	str_data6[i]= "";
        }
        try {
             BufferedReader br = new BufferedReader(new FileReader("C://Users//Srinithi//Downloads/patient.txt"));
             int i=0;
             while (strLine != null )
             {
                if(strLine=="*")
                	i++;
                strLine = br.readLine();
                if(strLine!=null)
                str_data1[i] = strLine;
                if(strLine!=null)
                strLine = br.readLine();
                if(strLine!=null)
                str_data2[i]= strLine;
                if(strLine!=null)
                strLine = br.readLine();
                if(strLine!=null)
                str_data3[i] = strLine;
                if(strLine!=null)
                strLine = br.readLine();
                if(strLine!=null)
                str_data4[i] = strLine;
                if(strLine!=null)
                strLine = br.readLine();
                if(strLine!=null)
                str_data5[i]= strLine;
                if(strLine!=null)
                strLine = br.readLine();
                if(strLine!=null)
                str_data6[i]= strLine;
                if(strLine!=null)
                strLine = br.readLine();
                System.out.println(str_data1[i]);
                System.out.println(str_data2[i]);
                System.out.println(str_data3[i]);
                System.out.println(str_data4[i]);
                System.out.println(str_data5[i]);
                System.out.println(str_data6[i]);
            }
           
             br.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            System.err.println("Unable to read the file.");
        }
     }
	}
/*System.out.println(p1.pid);
                            	                System.out.println(p1.pname);
                            	                System.out.println(p1.disease);
                            	                System.out.println(p1.sex);
                            	                System.out.println(p1.admit_status);
                            	                System.out.println(Age);*/

