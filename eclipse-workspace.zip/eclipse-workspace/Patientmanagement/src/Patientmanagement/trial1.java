package Patientmanagement;

import java.util.ArrayList;
import java.util.Scanner;

class appointment extends patient implements hospital {
	
	static String pid;
	static String pname;
	String disease;
	String dname;
	String date;
	String time;
	
	
	public void getdetails() {
		
		Scanner input = new Scanner(System.in);
		System.out.println("patient id:-");
        pid = input.nextLine();
        
        patient p = new patient();
        
        if(p.pid == appointment.pid){
        	appointment.pname=p.pname;
         }
        else {
        	System.out.println("Enter a valid patient id");
        }
      
        System.out.println("Disease:-");
        disease = input.nextLine();
        
        switch(disease) {
        
        case "fever":  dname = "Dr.R.Sarathi";
        case "dengue":  dname = "Dr. K . Rathnam";
        case "cancer":  dname = "Dr.M.Poonguzhalili";
        case "heart":  dname = "Dr.S. Smrithi";
        }
        
        System.out.println("date:-");
        date = input.nextLine();
        System.out.println("time:-");
        time = input.nextLine();
	}
	
	public void dispaly() {
		
		System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Patient id \t Patient Name \t Disease \t Doctor Name \t Date \t  Time");
        System.out.println("--------------------------------------------------------------------------------");
		System.out.println(appointment.pid+ "\t" + appointment.pname + "\t" + this.disease+ "\t" + this.dname+ "\t" + this.date+ "\t" + this.time);
	}
	
	
}
 
 
class prescription extends patient implements hospital{
	
	static String ppid;
	static String pid;
	static String pname;
	String mname;
	int mno, mcost;
	static int mtotal;
	
	public void getdetails() {
		
		Scanner input = new Scanner(System.in);
		System.out.println("prescription id:-");
		ppid = input.nextLine();
		
		System.out.println("patient id:-");
		pid = input.nextLine();
		
        patient p = new patient();
        
        if(p.pid == prescription.pid){
        	prescription.pname=p.pname;
         }
        else {
        	System.out.println("Enter a valid patient id");
        }
		
        System.out.println("medicine name:-");
		mname = input.nextLine();
		System.out.println("quantity:-");
		mno = input.nextInt();
		System.out.println("cost:-");
		mcost = input.nextInt();
		
		mtotal = mno*mcost;
	}
	
public void dispaly() {
	
	System.out.println("--------------------------------------------------------------------------------");
    System.out.println("Prescription id \t Patient Name \t Medicine Name \t Quantity \t Cost \t Total cost ");
    System.out.println("--------------------------------------------------------------------------------");	
    System.out.println(prescription.ppid+ "\t" + prescription.pname + "\t" + this.mname+ "\t" + this.mno+ "\t" + this.mcost+ "\t" + prescription.mtotal);
	}
}

class billing extends prescription implements hospital{
	
	String bid;
	static String pid;
	static String ppid;
	int cfee;
	static int mtotal;
	int btotal;
	
	public void getdetails() {
		
		cfee = 200;
		Scanner input = new Scanner(System.in);
		System.out.println("bill id:-");
		bid = input.nextLine();
		
		System.out.println("patient id:-");
		pid = input.nextLine();
		
		
        
        if(prescription.pid == billing.pid){
        	billing.ppid = prescription.ppid;
        	billing.mtotal = prescription.mtotal;

         }
        else {
        	System.out.println("Enter a valid prescription id");
        }
        
        btotal = cfee + mtotal;
		
	}
	
	public void display() {
		System.out.println("--------------------------------------------------------------------------------");
	    System.out.println("Bill id \t Patient id \t Prescription id \t Consultation fee \t Medicine cost \t Total Bill");
	    System.out.println("--------------------------------------------------------------------------------");	
		System.out.println(this.bid+ "\t" + billing.pid + "\t" + billing.ppid+ "\t" + this.cfee+ "\t" + billing.mtotal+ "\t" + this.btotal);

	}
}
public class trial1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
/*public void getdetails(ArrayList<patient> pat ) {
		
		Scanner input = new Scanner(System.in);
        int ch=1;
        while(ch==1)
        {
        	System.out.println("patient id:-");
            pid = input.nextLine();
        for(int i=0;i<pat.size()&&ch==1;i++)
            {
            	 patient p1 = pat.get(i); 
            	 if(p1.pid.equals(this.pid))
                 {
                      	pname=p1.pname;
                    	ch=0;
                    	break;
                }
            }
        if (ch==1)
        {
        	System.out.println("Enter a valid patient id");
        }
        }
        System.out.println("Disease:-");
        disease = input.nextLine();
        
        switch(disease) {
        
        case "fever":  dname = "Dr.R.Sarathi";
        break;
        case "dengue":  dname = "Dr. K . Rathnam";
        break;
        case "cancer":  dname = "Dr.M.Poonguzhalili";
        break;
        case "heart":  dname = "Dr.S. Smrithi";
        break;
        default :  System.out.println("Enter a valid disease!!");
        }
        
        case 5:
                {
                    s5= 1;
                    System.out.println("--------------------------------------------------------------------------------");
                    System.out.println("                    **APPOINTMENT SECTION**");
                    System.out.println("--------------------------------------------------------------------------------");
                    while (s5 == 1)
                    {
                        System.out.println("1.Add New Entry \n2.Existing Appointment List");
                        c1 = input.nextInt();
                        switch (c1)
                        {
                            case 1:
                                {
                                	a.add(new Appointment());                               	                                   
                                    	 Appointment a1 = a.get(cta);  
                                       	 a1.getdetails(p);                                    	 
                                         cta++;
                                    break;
                                }
                            case 2:
                                {
                                	System.out.println("--------------------------------------------------------------------------------");
                                    System.out.println("Patient id \t Patient Name \t Disease \t Doctor Name \t Date \t  Time");
                                    System.out.println("--------------------------------------------------------------------------------");
                                    for (int i=0 ; i<a.size();i++)
                                    {
                                    	Appointment ap = a.get(i); 
                                    	
                                    	 ap.display();
                                    }
                                    break;
                                }
                        }
                        System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                        s5 = input.nextInt();
                    }
                    break;
                }
         */
